> **Fork and modification notice:** This Inkora-branded build is a modified version of QuickNovel by LagradOst. The original project and its contributors retain their applicable copyright. This project is distributed under the GNU GPL-3.0; see `LICENSE`. If you redistribute this modified version, comply with GPL-3.0, including providing corresponding source code and preserving required notices.

# Inkora (modified QuickNovel fork)

**English** | [Русский](README_RU.md)

Adfree FOSS Android app for downloading novels. It also functions as an Epub reader.

**Discord:** https://discord.gg/5Hus6fM

**Download:** https://github.com/LagradOst/QuickNovel/releases

**Providers used:** 

- https://allnovel.org
- https://annas-archive.org
- https://bestlightnovel.com
- https://chrysanthemumgarden.com
- https://www.fanmtl.com
- https://fenrirealm.com
- https://free.kolnovel.com
- https://freewebnovel.com
- https://fucknovelpia.com
- https://graycity.net
- https://hiraethtranslation.com
- https://indowebnovel.id
- https://libread.com
- https://lightnovelstranslations.com
- https://lightnovelworld.org
- https://lnmtl.com
- https://meionovels.com
- https://mtlnovel.me
- https://www.nobadnovel.com
- https://novelbin.com
- https://novelbuddy.com
- https://novelfire.net
- https://novelfull.com
- https://novelsonline.org
- https://novlove.com
- https://pawread.com
- https://readfrom.net
- https://readnovelfull.com
- https://readonlinefreebook.com
- https://rewayat.club
- https://risenovel.com
- https://www.royalroad.com
- https://sakuranovel.id
- https://www.scribblehub.com
- https://www.skynovels.net
- https://www.sonicmtl.com
- https://wtr-lab.com
- https://wuxia.click
- https://www.wuxiabox.com

**Screenshoots:**

<img src="./.github/home.jpg" height="400"/><img src="./.github/search.jpg" height="400"/><img src="./.github/downloads.jpg" height="400"/><img src="./.github/result.jpg" height="400"/><img src="./.github/reader.jpg" height="400"/>

**Legal notice:**

Any legal issues regarding the content on this application should be taken up with the actual file hosts and providers themselves as we are not affiliated with them.

In case of copyright infringement, please directly contact the responsible parties or the streaming websites.

The app is purely for educational and personal use.

Inkora does not host any content on the app, and has no control over what media is put up or taken down. QuickNovel functions like any other search engine, such as Google. QuickNovel does not host, upload or manage any videos, films or content. It simply crawls, aggregates and displayes links in a convenient, user-friendly interface.

It merely scrapes 3rd-party websites that are publicly accessable via any regular web browser. It is the responsibility of user to avoid any actions that might violate the laws governing his/her locality. Use Inkora at your own risk.

