package com.lagradost.quicknovel.util

import android.content.Context
import android.graphics.drawable.Drawable
import android.text.Spanned
import android.widget.TextView
import coil3.ImageLoader
import coil3.SingletonImageLoader.get
import coil3.asDrawable
import coil3.request.Disposable
import coil3.request.ImageRequest
import coil3.target.Target
import io.noties.markwon.AbstractMarkwonPlugin
import io.noties.markwon.MarkwonConfiguration
import io.noties.markwon.MarkwonSpansFactory
import io.noties.markwon.image.AsyncDrawable
import io.noties.markwon.image.AsyncDrawableLoader
import io.noties.markwon.image.AsyncDrawableScheduler
import io.noties.markwon.image.DrawableUtils
import io.noties.markwon.image.ImageSpanFactory
import org.commonmark.node.Image
import java.util.concurrent.atomic.AtomicBoolean

class CoilImagesPlugin : AbstractMarkwonPlugin {
    interface CoilStore {
        fun load(drawable: AsyncDrawable): ImageRequest

        fun cancel(disposable: Disposable)
    }
    companion object {
    fun create(context: Context): CoilImagesPlugin {
        return create(context, object : CoilStore {
            override fun load(drawable: AsyncDrawable): ImageRequest {
                return ImageRequest.Builder(context)
                    .data(drawable.destination)
                    .build()
            }

            override fun cancel(disposable: Disposable) {
                disposable.dispose()
            }
        }, get(context))
    }

    fun create(
        context: Context,
        imageLoader: ImageLoader
    ): CoilImagesPlugin {
        return create(context, object : CoilStore {
            override fun load(drawable: AsyncDrawable): ImageRequest {
                return ImageRequest.Builder(context)
                    .data(drawable.destination)
                    .build()
            }

            override fun cancel(disposable: Disposable) {
                disposable.dispose()
            }
        }, imageLoader)
    }

    fun create(
        context: Context,
        coilStore: CoilStore,
        imageLoader: ImageLoader
    ): CoilImagesPlugin {
        return CoilImagesPlugin(context, coilStore, imageLoader)
    }
    }
    val coilAsyncDrawableLoader: CoilAsyncDrawableLoader

    constructor(context: Context, coilStore: CoilStore, imageLoader: ImageLoader) {
        this.coilAsyncDrawableLoader =
            CoilAsyncDrawableLoader(
                context,
                coilStore,
                imageLoader
            )
    }

    override fun configureSpansFactory(builder: MarkwonSpansFactory.Builder) {
        builder.setFactory<Image?>(Image::class.java, ImageSpanFactory())
    }

    override fun configureConfiguration(builder: MarkwonConfiguration.Builder) {
        builder.asyncDrawableLoader(coilAsyncDrawableLoader)
    }

    override fun beforeSetText(textView: TextView, markdown: Spanned) {
        AsyncDrawableScheduler.unschedule(textView)
    }

    override fun afterSetText(textView: TextView) {
        AsyncDrawableScheduler.schedule(textView)
    }

    class CoilAsyncDrawableLoader internal constructor(
        private val context: Context,
        private val coilStore: CoilStore,
        private val imageLoader: ImageLoader
    ) : AsyncDrawableLoader() {
        private val cache: MutableMap<AsyncDrawable?, Disposable?> =
            HashMap<AsyncDrawable?, Disposable?>(2)

        override fun load(drawable: AsyncDrawable) {
            val loaded = AtomicBoolean(false)
            val target: Target = AsyncDrawableTarget(context, drawable, loaded)
            val request = coilStore.load(drawable).newBuilder()
                .target(target)
                .build()
            // @since 4.5.1 execute can return result _before_ disposable is created,
            //  thus `execute` would finish before we put disposable in cache (and thus result is
            //  not delivered)
            val disposable = imageLoader.enqueue(request)
            // if flag was not set, then job is running (else - finished before we got here)
            if (!loaded.get()) {
                // mark flag
                loaded.set(true)
                cache.put(drawable, disposable)
            }
        }

        override fun cancel(drawable: AsyncDrawable) {
            val disposable = cache.remove(drawable)
            if (disposable != null) {
                coilStore.cancel(disposable)
            }
        }

        override fun placeholder(drawable: AsyncDrawable): Drawable? {
            return null
        }

        private inner class AsyncDrawableTarget(
            private val context: Context,
            private val drawable: AsyncDrawable,
            private val loaded: AtomicBoolean
        ) : Target {
            override fun onSuccess(result: coil3.Image) {
                val loadedDrawable = result.asDrawable(context.resources)

                // @since 4.5.1 check finished flag (result can be delivered _before_ disposable is created)
                if (cache.remove(drawable) != null
                    || !loaded.get()
                ) {
                    // mark
                    loaded.set(true)
                    if (drawable.isAttached) {
                        DrawableUtils.applyIntrinsicBoundsIfEmpty(loadedDrawable)
                        drawable.setResult(loadedDrawable)
                    }
                }
            }

            override fun onError(error: coil3.Image?) {
                val errorDrawable = error?.asDrawable(context.resources)
                if (cache.remove(drawable) != null) {
                    if (errorDrawable != null && drawable.isAttached) {
                        DrawableUtils.applyIntrinsicBoundsIfEmpty(errorDrawable)
                        drawable.setResult(errorDrawable)
                    }
                }
            }

            override fun onStart(placeholder: coil3.Image?) {
                val placeholder = placeholder?.asDrawable(context.resources)
                if (placeholder != null && drawable.isAttached) {
                    DrawableUtils.applyIntrinsicBoundsIfEmpty(placeholder)
                    drawable.setResult(placeholder)
                }
            }
        }
    }
}