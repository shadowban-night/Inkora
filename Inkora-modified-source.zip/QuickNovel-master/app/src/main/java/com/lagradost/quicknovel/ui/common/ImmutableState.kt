package com.lagradost.quicknovel.ui.common

/**
 * Immutable state for UI and state management.
 *
 * All state must be immutable and copied with "copy" for any operation modifying the state.
 *
 * This is because compose likes immutable state for UI, and makes it a lot easier to handle multithreading.
 *
 * 1. Lock free
 * 2. Fully immutable
 * 3. Exception free, no ConcurrentModificationException
 *
 * The labels describe how these classes are used and where.
 * */

import android.content.Context
import androidx.annotation.CheckResult
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.net.toUri
import coil3.network.NetworkHeaders
import coil3.network.httpHeaders
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.request.transformations
import com.lagradost.cloudstream4.state.FilterByQuery
import com.lagradost.cloudstream4.state.SearchableData
import com.lagradost.cloudstream4.state.SortByName
import com.lagradost.cloudstream4.state.rev
import com.lagradost.cloudstream4.state.sortByFloat
import com.lagradost.cloudstream4.state.sortByLong
import com.lagradost.quicknovel.BaseApplication
import com.lagradost.quicknovel.BaseApplication.Companion.getKey
import com.lagradost.quicknovel.BaseApplication.Companion.setKey
import com.lagradost.quicknovel.BookDownloader2.downloadProgress
import com.lagradost.quicknovel.BookDownloader2Helper
import com.lagradost.quicknovel.BookDownloader2Helper.IMPORT_SOURCE
import com.lagradost.quicknovel.BookDownloader2Helper.IMPORT_SOURCE_PDF
import com.lagradost.quicknovel.BookDownloader2Helper.generateId
import com.lagradost.quicknovel.BookDownloader2Helper.getFilenameIMG
import com.lagradost.quicknovel.BookDownloader2Helper.sanitizeFilename
import com.lagradost.quicknovel.ChapterData
import com.lagradost.quicknovel.DOWNLOAD_EPUB_LAST_ACCESS
import com.lagradost.quicknovel.DOWNLOAD_EPUB_SIZE
import com.lagradost.quicknovel.DownloadExtractLink
import com.lagradost.quicknovel.DownloadLink
import com.lagradost.quicknovel.DownloadProgressState
import com.lagradost.quicknovel.DownloadState
import com.lagradost.quicknovel.EPUB_CURRENT_POSITION
import com.lagradost.quicknovel.EpubResponse
import com.lagradost.quicknovel.HISTORY_FOLDER
import com.lagradost.quicknovel.HeadMainPageResponse
import com.lagradost.quicknovel.LoadResponse
import com.lagradost.quicknovel.MainActivity
import com.lagradost.quicknovel.MainActivity.Companion.loadResult
import com.lagradost.quicknovel.R
import com.lagradost.quicknovel.ReleaseStatus
import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.StreamResponse
import com.lagradost.quicknovel.UserReview
import com.lagradost.quicknovel.ui.download.DownloadFragment
import com.lagradost.quicknovel.util.BlurTransformation
import com.lagradost.quicknovel.util.ResultCached
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.ImmutableMap
import kotlinx.collections.immutable.PersistentList
import kotlinx.collections.immutable.PersistentMap
import kotlinx.collections.immutable.PersistentSet
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.persistentMapOf
import kotlinx.collections.immutable.persistentSetOf
import kotlinx.collections.immutable.toImmutableList
import kotlinx.collections.immutable.toImmutableMap
import kotlinx.collections.immutable.toPersistentList
import kotlinx.collections.immutable.toPersistentMap
import kotlinx.collections.immutable.toPersistentSet
import me.xdrop.fuzzywuzzy.FuzzySearch
import kotlin.uuid.Uuid


/**
 * UI -> ViewModel
 *
 * Action on ImmutableSearchResponse */
enum class SearchResponseOperation {
    /** Open the item in a result view */
    Open,

    /** Read the epub */
    Read,

    /** Stream read the item */
    Stream,

    /** Ask the viewmodel to delete this item, from e.g. history or bookmarks. This should not delete the item directly */
    AskDelete,

    /** Actually delete this item */
    Delete,

    /** Show a popup of metadata */
    Metadata,

    /** Download the item */
    Download,

    /** Pause the download of the item */
    Pause,

    /** Resume the download of the item */
    Resume,

    /** Stop the download of this item */
    Stop,

    /** No operation */
    NoOp,
}

@Immutable
data class ImmutableChapterData(
    val name: String,
    val url: String,
    val dateOfRelease: String? = null,
    val views: Int? = null,
    val randomUuid: Uuid = Uuid.random(),
    val index: Int,
) {
    companion object {
        fun from(chapter: ChapterData, index: Int): ImmutableChapterData =
            ImmutableChapterData(
                name = chapter.name,
                url = chapter.url,
                dateOfRelease = chapter.dateOfRelease,
                views = chapter.views,
                index = index,
            )
    }

    fun matchesQuery(query: String): Boolean =
        FuzzySearch.partialRatio(name.lowercase(), query) > 50
}

@Immutable
data class ImmutableReview(
    val content: String,
    val title: String? = null,
    val username: String? = null,
    val date: String? = null,
    val avatarUrl: String? = null,
    val avatarHeaders: PersistentMap<String, String>? = null,
    val rating: Int? = null,
    val ratings: PersistentList<Pair<Int, String>>? = null,
    val containsSpoilers: Boolean = false,
    val randomUuid: Uuid = Uuid.random()
) {
    companion object {
        fun from(review: UserReview): ImmutableReview =
            ImmutableReview(
                content = review.review,
                title = review.title,
                username = review.username,
                date = review.date,
                avatarUrl = review.avatarUrl,
                avatarHeaders = review.avatarHeaders?.toPersistentMap(),
                rating = review.rating,
                ratings = review.ratings?.toPersistentList(),
                containsSpoilers = review.containsSpoilers
            )
    }

    val imageRequest
        get() = @Composable {
            val context = LocalContext.current
            remember(context) {
                ImageRequest(context)
            }
        }

    fun ImageRequest(context: Context): ImageRequest =
        ImageRequest.Builder(context)
            .data(avatarUrl)
            .httpHeaders(NetworkHeaders.Builder().also { headerBuilder ->
                avatarHeaders?.forEach { (key, value) ->
                    headerBuilder[key] = value
                }
            }.build())
            .crossfade(true)
            .build()

}

@Immutable
data class ImmutableLoadData(
    val related: PersistentList<ImmutableSearchResponse>?,
    val status: ReleaseStatus?,
    val chapters: PersistentList<ImmutableChapterData>?,
    val views: Int?,
    val peopleVoted: Int?,

    // TODO make this better
    var downloadLinks: PersistentList<DownloadLink>?,
    var downloadExtractLinks: PersistentList<DownloadExtractLink>?,
)

/**
 * Viewmodel -> UI+Viewmodel
 *
 * The main class for representing a single "item" with a poster and name.
 *
 * This is the same for both downloads, imports, bookmarks, history and response.
 *
 * But with different fields non-null, the main is "id" where having an "id"
 * means we have at some time entered it, meaning it must be a "cached" value.
 *
 * The other main field is downloadState which is only non-null on the downloaded "page".
 * */
@Immutable
data class ImmutableSearchResponse(
    /** Name of the item */
    val name: String,
    /** API used for accessing the item */
    val apiName: String,
    /** Author written, this will be null on search items */
    val author: String? = null,
    /** The web url to OPEN the page */
    val url: String,
    /** The web url to the poster, use imageRequest instead */
    val posterUrl: String? = null,
    /** The web headers of the posterUrl, use imageRequest instead */
    val posterHeaders: ImmutableMap<String, String>? = null,
    /** The "score" or "rating" of the item */
    val rating: Int? = null,
    /** The latest chapter name to display */
    val latestChapterName: String? = null,
    /** This is a random uuid that is stable for e.g. using a key but not persistent between launches */
    val randomUuid: Uuid = Uuid.random(),
    /** The total chapter count, use chapters instead to also work on downloaded items */
    private val totalChapters: Long? = null,
    /** The current download state, only present on "downloaded" items */
    val downloadState: ImmutableDownloadState? = null,
    /** The "synopsis" or "plot" of the item, absent for regular search results */
    val synopsis: String? = null,
    /** The tags of an item */
    val tags: ImmutableList<String>? = null,
    /** If the item is "loading" in some way, like generating an epub or having some misc loading state unrelated to "downloading" */
    val generating: Boolean = false,
    /** The ID of a card used for all keys, only non-null on regular search results */
    val id: Int? = null,
    /** The time we "cached"/"stored" the item and its metadata also known as "Recently refreshed" */
    val timeOfCached: Long,
    /** The time a "new" chapter got downloaded, also known as "Recently updated" */
    val timeOfChapterDownloaded: Long? = null,
    /** The time we opened the item in the full results view or read it, also known as "Recently opened" */
    val timeOfPageOpened: Long? = null,
    /** The size of the last written epub in chapters, aka how many chapters have we actually might have read */
    val epubSize: Int? = null,
    /** How many chapters we have read with the built-in reader */
    val chaptersRead: Int,
    val loadData: ImmutableLoadData? = null,
    val reviewData: String? = null,
) {

    fun matchesQuery(query: String): Boolean =
        FuzzySearch.partialRatio(name.lowercase(), query) > 50

    val chapters: Long? get() = totalChapters ?: downloadState?.total
    val isImported: Boolean get() = (apiName == IMPORT_SOURCE || apiName == IMPORT_SOURCE_PDF)
    val hasNewChapters: Boolean get() = downloadState != null && epubSize != null && !isImported && epubSize < downloadState.progress

    val imageRequest
        get() = @Composable {
            val context = LocalContext.current
            remember(context) {
                ImageRequest(context)
            }
        }
    val blurImageRequest
        get() = @Composable {
            val context = LocalContext.current
            remember(context) {
                ImageRequest(context, radius = 100, sample = 3)
            }
        }

    fun ImageRequest(
        context: Context,
        radius: Int = 0,
        sample: Int = 3
    ): ImageRequest {
        val transformations = if (radius > 0) listOf(
            BlurTransformation(
                scale = sample.toFloat(),
                radius = radius
            )
        ) else emptyList()

        return if (isImported) {
            val uri = (context.filesDir.toString() + getFilenameIMG(
                sanitizeFilename(apiName),
                sanitizeFilename(author ?: ""),
                sanitizeFilename(name)
            )).toUri()
            ImageRequest.Builder(context)
                .data(uri)
                .crossfade(true).transformations(transformations)
                .build()
        } else {
            ImageRequest.Builder(context)
                .data(posterUrl)
                .httpHeaders(NetworkHeaders.Builder().also { headerBuilder ->
                    posterHeaders?.forEach { (key, value) ->
                        headerBuilder[key] = value
                    }
                }.build())
                .crossfade(true).transformations(transformations)
                .build()
        }
    }

    fun toResultCached(
        id: Int,
    ): ResultCached {
        return ResultCached(
            source = url,
            name = name,
            apiName = apiName,
            id = id,
            author = author,
            poster = posterUrl,
            tags = tags,
            rating = rating,
            totalChapters = loadData?.chapters?.size ?: downloadState?.total?.toInt() ?: 1,
            cachedTime = System.currentTimeMillis(),
            synopsis = synopsis,
            posterHeaders = posterHeaders
        )
    }

    companion object {
        fun preview(): ImmutableSearchResponse = ImmutableSearchResponse(
            name = "hello world",
            apiName = "hello world",
            author = "author",
            url = "url",
            posterUrl = "https://www.royalroadcdn.com/public/covers-full/36735-the-perfect-run.jpg?time=${System.currentTimeMillis()}",
            posterHeaders = null,
            loadData = ImmutableLoadData(
                related = persistentListOf(),
                status = ReleaseStatus.Ongoing,
                chapters = persistentListOf(),
                views = 1337,
                peopleVoted = 42,
                downloadLinks = null,
                downloadExtractLinks = null,
            ),
            tags = persistentListOf(
                "tag 1",
                "tag 2",
                "tag 3",
                "tag 4",
                "tag 5",
                "tag 6",
                "tag 7",
                "tag 8",
                "tag 9",
                "Hello World",
                "More tags"
            ),
            synopsis = "synopsis",
            id = 0,
            rating = 123,
            latestChapterName = "hello world chapters",
            generating = false,
            chaptersRead = 0,
            timeOfCached = 0,
            downloadState = ImmutableDownloadState(
                status = DownloadState.Nothing,
                progress = 123,
                downloaded = 50,
                total = 200,
                lastUpdatedMs = System.currentTimeMillis(),
                etaMs = 65240
            )
        )

        fun chaptersRead(name: String): Int =
            getKey<Int>(EPUB_CURRENT_POSITION, name)?.let { it + 1 } ?: 0

        fun addToHistory(response: ImmutableSearchResponse) {
            val id = response.id ?: return
            // we won't add it to history from cache
            setKey(
                HISTORY_FOLDER, id.toString(), response.toResultCached(id)
            )
        }

        fun timeOfPageOpened(id: Int): Long = getKey<Long>(
            DOWNLOAD_EPUB_LAST_ACCESS,
            id.toString(),
        ) ?: 0L

        fun epubSize(id: Int): Int = getKey(DOWNLOAD_EPUB_SIZE, id.toString()) ?: 0

        fun setTimeOfPageOpened(id: Int, value: Long) {
            setKey(
                DOWNLOAD_EPUB_LAST_ACCESS,
                id.toString(), value
            )
        }

        fun setEpubSize(id: Int, value: Int) {
            setKey(
                DOWNLOAD_EPUB_SIZE,
                id.toString(), value
            )
        }

        fun from(response: SearchResponse): ImmutableSearchResponse =
            ImmutableSearchResponse(
                name = response.name,
                url = response.url,
                posterUrl = response.posterUrl,
                rating = response.rating,
                latestChapterName = response.latestChapter,
                apiName = response.apiName,
                posterHeaders = response.posterHeaders?.toImmutableMap(),
                timeOfCached = System.currentTimeMillis(),
                chaptersRead = chaptersRead(response.name)
            )

        fun from(response: LoadResponse): ImmutableSearchResponse {
            val id = generateId(response, response.apiName)
            val epubResponse = (response as? EpubResponse)
            val streamResponse = (response as? StreamResponse)

            val currentDownloadProgress =
                downloadProgress[id] ?: BookDownloader2Helper.downloadInfo(
                    BaseApplication.context,
                    response.author,
                    response.name,
                    response.apiName
                )?.let { info ->
                    DownloadProgressState(
                        state = DownloadState.Nothing,
                        progress = info.progress,
                        total = info.total,
                        downloaded = info.downloaded,
                        lastUpdatedMs = System.currentTimeMillis(),
                        etaMs = null
                    )
                } ?: run {
                    DownloadProgressState(
                        state = DownloadState.Nothing,
                        progress = 0,
                        total = streamResponse?.data?.size?.toLong() ?: 1,
                        downloaded = 0,
                        lastUpdatedMs = System.currentTimeMillis(),
                        etaMs = null
                    )
                }

            return ImmutableSearchResponse(
                id = id,
                name = response.name,
                url = response.url,
                posterUrl = response.posterUrl,
                rating = response.rating,
                apiName = response.apiName,
                author = response.author,
                synopsis = response.synopsis,
                loadData = ImmutableLoadData(
                    related = response.related?.map { from(it) }?.toPersistentList(),
                    status = response.status,
                    chapters = streamResponse?.data?.mapIndexed { index, data ->
                        ImmutableChapterData.from(
                            data, index
                        )
                    }?.toPersistentList(),
                    downloadLinks = epubResponse?.downloadLinks?.toPersistentList(),
                    downloadExtractLinks = epubResponse?.downloadExtractLinks?.toPersistentList(),
                    views = response.views,
                    peopleVoted = response.peopleVoted,
                ),
                reviewData = response.reviewData,
                tags = response.tags?.toPersistentList(),
                posterHeaders = response.posterHeaders?.toImmutableMap(),
                timeOfCached = System.currentTimeMillis(),
                chaptersRead = chaptersRead(response.name),
                downloadState = ImmutableDownloadState.from(currentDownloadProgress)
            )
        }


        fun from(cache: ResultCached): ImmutableSearchResponse =
            ImmutableSearchResponse(
                name = cache.name,
                url = cache.source,
                posterUrl = cache.poster,
                posterHeaders = cache.posterHeaders?.toPersistentMap(),
                apiName = cache.apiName,
                rating = cache.rating,
                id = cache.id,
                timeOfCached = cache.cachedTime,
                totalChapters = cache.totalChapters.toLong(),
                author = cache.author,
                synopsis = cache.synopsis,
                timeOfPageOpened = timeOfPageOpened(cache.id),
                chaptersRead = chaptersRead(cache.name)
            )

        fun from(
            id: Int,
            cache: DownloadFragment.DownloadData,
            downloadState: ImmutableDownloadState? = null
        ) =
            ImmutableSearchResponse(
                name = cache.name,
                url = cache.source,
                posterUrl = cache.posterUrl,
                posterHeaders = cache.posterHeaders?.toPersistentMap(),
                apiName = cache.apiName,
                rating = cache.rating,
                id = id,
                timeOfCached = cache.lastUpdated ?: System.currentTimeMillis(),
                timeOfChapterDownloaded = cache.lastDownloaded,
                author = cache.author,
                downloadState = downloadState,
                synopsis = cache.synopsis,
                tags = cache.tags?.toImmutableList(),
                timeOfPageOpened = timeOfPageOpened(id),
                epubSize = epubSize(id),
                chaptersRead = chaptersRead(cache.name)
            )
    }

    fun doAction(operation: SearchResponseOperation) {
        when (operation) {
            SearchResponseOperation.Open -> {
                if (!isImported) {
                    loadResult(url, apiName)
                }
            }

            SearchResponseOperation.Metadata -> {
                MainActivity.loadPreviewPage(this)
            }

            SearchResponseOperation.NoOp -> {}
            else -> throw NotImplementedError()
        }
    }
}

/**
 * UI -> Viewmodel
 *
 * The response from the UI about an action on a ImmutableSearchResponse */
@Immutable
data class SearchResponseAction(
    val response: ImmutableSearchResponse,
    val operation: SearchResponseOperation,
) {
    fun doAction() {
        response.doAction(operation)
    }
}

/**
 * Book downloader -> Viewmodel + UI
 *
 * The download state of a ImmutableSearchResponse */
@Immutable
data class ImmutableDownloadState(
    val status: DownloadState,
    /** How many chapters/bytes much have we downloaded, not including skipped chapters */
    val progress: Long,
    /** How many have we actually downloaded */
    val downloaded: Long,
    /** How many is there in total */
    val total: Long,
    /** When was this state updated */
    val lastUpdatedMs: Long,
    /** How many milliseconds until this item is fully downloaded */
    val etaMs: Long?
) {
    val downloadPercentage get() = downloaded.toFloat() / maxOf(total, 1)
    val progressPercentage get() = progress.toFloat() / maxOf(total, 1)

    companion object {
        fun from(state: DownloadProgressState) = ImmutableDownloadState(
            status = state.state,
            progress = state.progress,
            downloaded = state.downloaded,
            total = state.total,
            lastUpdatedMs = state.lastUpdatedMs,
            etaMs = state.etaMs
        )
    }

    /** Get the associated action */
    val action: DownloadStateAction get() = DownloadStateAction(status)
}

@Immutable
data class DownloadStateAction(
    val status: DownloadState
) {
    val operation
        get() =
            when (status) {
                DownloadState.IsDownloading -> SearchResponseOperation.Stop
                DownloadState.IsPaused -> SearchResponseOperation.Resume
                DownloadState.IsStopped -> SearchResponseOperation.Download
                DownloadState.IsFailed -> SearchResponseOperation.Download
                DownloadState.IsDone -> SearchResponseOperation.Download
                DownloadState.IsPending -> SearchResponseOperation.NoOp
                DownloadState.Nothing -> SearchResponseOperation.Download
            }

    val operationName
        get() =
            when (status) {
                DownloadState.IsDownloading -> R.string.stop
                DownloadState.IsPaused -> R.string.resume
                DownloadState.IsStopped -> R.string.stopped
                DownloadState.IsFailed -> R.string.failed
                DownloadState.IsDone -> R.string.downloaded
                DownloadState.IsPending -> R.string.loading
                DownloadState.Nothing -> R.string.download
            }

    val icon
        get() = when (status) {
            DownloadState.IsDownloading -> R.drawable.stop_circle_24px
            DownloadState.IsPaused -> R.drawable.play_arrow_24px
            DownloadState.IsStopped -> R.drawable.arrow_circle_down_24px
            DownloadState.IsFailed -> R.drawable.arrow_circle_down_24px
            DownloadState.IsDone -> R.drawable.check
            DownloadState.IsPending -> R.drawable.nothing
            DownloadState.Nothing -> R.drawable.arrow_circle_down_24px
        }

    val iconBig
        get() = when (status) {
            DownloadState.IsDownloading -> R.drawable.ic_baseline_stop_24
            DownloadState.IsPaused -> R.drawable.netflix_play
            DownloadState.IsStopped -> R.drawable.ic_sharp_clear_24
            DownloadState.IsFailed -> R.drawable.ic_sharp_clear_24
            DownloadState.IsDone -> R.drawable.ic_baseline_check_24
            DownloadState.IsPending -> R.drawable.nothing
            DownloadState.Nothing -> R.drawable.netflix_download
        }
}

/**
 * API -> Viewmodel
 * */
@Immutable
data class ImmutableHeadMainPageResponse(
    val url: String,
    val list: ImmutableList<ImmutableSearchResponse>,
) {
    companion object {
        fun from(response: HeadMainPageResponse) = ImmutableHeadMainPageResponse(
            url = response.url,
            list = response.list.map(ImmutableSearchResponse::from).toImmutableList()
        )
    }
}

/**
 * Viewmodel
 *
 * All sorting methods for sorting a ImmutableDownloadState
 * */
@Immutable
enum class SortingMethodType(val id: Int) {
    /** Default,  */
    Default(0),

    /** Ordering on the name */
    Alphabetical(1),
    RevAlphabetical(2),

    /** Download count, aka chapters downloaded */
    DownloadCount(3),
    RevDownloadCount(4),

    /** Download Percentage, aka chapters downloaded / total chapters or bytes */
    DownloadPercentage(5),
    RevDownloadPercentage(6),

    /** Last opened */
    LastOpened(7),
    RevLastOpened(8),

    /** Last update of *new* content */
    LastNewChapterDownloaded(9),
    RevLastNewChapterDownloaded(10),

    /**
     * In the case of downloads, this is the
     * Last update time the downloader was invoked,
     * even if no chapter was downloaded.
     *
     * For history this is when they are added
     * */
    LastCached(13),
    RevLastCached(14),
    ChapterCount(15),
    RevChapterCount(16);

    companion object {
        fun from(value: Int): SortingMethodType {
            return entries.firstOrNull { it.id == value } ?: Default
        }
    }
}

@Immutable
enum class ChapterSortingMethodType(val id: Int) {
    /** Default */
    Default(0),

    /** Ordering by index */
    Ascending(1),
    RevAscending(2),

    /** Ordering on the name */
    Alphabetical(3),
    RevAlphabetical(4);

    companion object {
        fun from(value: Int): ChapterSortingMethodType {
            return entries.firstOrNull { it.id == value } ?: Default
        }
    }
}

@Immutable
enum class ChapterFilterMethodType(val id: Int) {
    /** Filter by download status */
    Downloaded(1),
    UnDownloaded(2),

    /** Filter by read */
    Read(3),
    UnRead(4),

    /** Filter by bookmark status */
    Bookmark(5),
    UnBookmark(6);

    companion object {
        fun from(value: Int): ChapterFilterMethodType? {
            return entries.firstOrNull { it.id == value }
        }
    }
}

/**
 * UI
 *
 * The UI options for selecting a sorting method
 * */
@Immutable
data class SortingMethodPair(
    @StringRes val name: Int,
    val id: SortingMethodType,
    /** if inverse == id then it is a singular option */
    val inverse: SortingMethodType = id
)

/**
 * UI
 *
 * Sorting methods for downloaded ImmutableDownloadState
 * */
val sortingMethods = persistentListOf(
    SortingMethodPair(R.string.default_sort, SortingMethodType.Default),
    SortingMethodPair(
        R.string.recently_sort,
        SortingMethodType.LastOpened,
        SortingMethodType.RevLastOpened
    ),
    SortingMethodPair(
        R.string.recently_updated_sort,
        SortingMethodType.LastNewChapterDownloaded,
        SortingMethodType.RevLastNewChapterDownloaded
    ),
    SortingMethodPair(
        R.string.recently_checked_sort,
        SortingMethodType.LastCached,
        SortingMethodType.RevLastCached
    ),

    SortingMethodPair(
        R.string.alpha_sort,
        SortingMethodType.Alphabetical,
        SortingMethodType.RevAlphabetical
    ),
    SortingMethodPair(
        R.string.download_sort,
        SortingMethodType.DownloadCount,
        SortingMethodType.RevDownloadCount
    ),
    SortingMethodPair(
        R.string.download_perc, SortingMethodType.DownloadPercentage,
        SortingMethodType.RevDownloadPercentage
    ),
    SortingMethodPair(
        R.string.chapters, SortingMethodType.ChapterCount,
        SortingMethodType.RevChapterCount
    ),
)

/**
 * UI
 *
 * Sorting methods for any ImmutableDownloadState */
val normalSortingMethods = persistentListOf(
    SortingMethodPair(R.string.default_sort, SortingMethodType.Default),
    SortingMethodPair(
        R.string.recently_sort,
        SortingMethodType.LastOpened,
        SortingMethodType.RevLastOpened
    ),
    /*SortingMethodPair(
        R.string.recently_visisted_sort,
        SortingMethodType.LastCached,
        SortingMethodType.RevLastCached
    ),*/
    SortingMethodPair(
        R.string.alpha_sort,
        SortingMethodType.Alphabetical,
        SortingMethodType.RevAlphabetical
    ),
    SortingMethodPair(
        R.string.chapters, SortingMethodType.ChapterCount,
        SortingMethodType.RevChapterCount
    )
)

/**
 * Viewmodel
 *
 * Updates a singular index of a PersistentList with the new value, returning the update state
 * */
@CheckResult
fun <T> PersistentList<T>.updateRow(
    index: Int,
    update: T.() -> T
): PersistentList<T> {
    val item = this.getOrNull(index) ?: return this
    val newItem = update(item)
    return this.replacingAt(index, newItem)
}

/**
 * Viewmodel
 *
 * Updates a singular ImmutableSearchResponse of a PersistentList with the new value, returning the update state
 *
 * This is done by updating based on the url, as that is assumed to be unique
 * */
@CheckResult
fun PersistentList<ImmutableSearchResponse>.updateItem(
    item: ImmutableSearchResponse,
    update: ImmutableSearchResponse.() -> ImmutableSearchResponse
): PersistentList<ImmutableSearchResponse> {
    val index = this.indexOfFirst { it.url == item.url }
    if (index == -1) return this
    val newItem = update(this[index])
    return this.replacingAt(index, newItem)
}

/**
 * Viewmodel
 *
 * Update each item inside the PersistentList using the update function
 *
 * */
@CheckResult
fun <T> PersistentList<T>.updateRows(
    update: T.(Int) -> T
): PersistentList<T> {
    return this.mapIndexed { index, t -> t.update(index) }.toPersistentList()
}

/**
 * Contrary to the SearchList, the chapter data will be truly immutable
 * therefore we use the PersistentList<ImmutableChapterData> instead of passing by index/id
 *
 * TODO bitset for downloads
 * TODO bitset for read status
 * */
@Immutable
data class ImmutableChapterList(
    private val data: PersistentList<ImmutableChapterData>,
    private val filtered: PersistentList<ImmutableChapterData> = persistentListOf(),
    val sorted: PersistentList<ImmutableChapterData> = persistentListOf(),
    val query: String = "",
    val sortingMethod: ChapterSortingMethodType = ChapterSortingMethodType.Default,
    //val filterMethod: EnumSet<ChapterFilterMethodType> = EnumSet.allOf<ChapterFilterMethodType>(), // TODO
) {

    @CheckResult
    fun search(
        query: String = this.query,
        sortingMethod: ChapterSortingMethodType = this.sortingMethod
    ): ImmutableChapterList {
        val sameQuery = this.query == query
        val sameSorting = this.sortingMethod == sortingMethod

        val filtered = if (sameQuery) {
            filtered
        } else {
            filterList(data, query)
        }
        val sorted = if (sameSorting && sameQuery) {
            sorted
        } else {
            sortList(filtered, sortingMethod)
        }

        return this.copy(
            filtered = filtered,
            sorted = sorted,
            query = query,
            sortingMethod = sortingMethod,
        )
    }

    companion object {
        @CheckResult
        fun filterList(
            data: PersistentList<ImmutableChapterData>,
            query: String
        ): PersistentList<ImmutableChapterData> {
            if (query.trim().length < 2) return data
            return data.removingAll { item -> !item.matchesQuery(query) }
        }

        @CheckResult
        fun sortList(
            list: PersistentList<ImmutableChapterData>,
            method: ChapterSortingMethodType
        ): PersistentList<ImmutableChapterData> {
            val sorted = when (method) {
                ChapterSortingMethodType.Default, ChapterSortingMethodType.Ascending -> list
                ChapterSortingMethodType.RevAscending -> list.asReversed().toPersistentList()
                ChapterSortingMethodType.Alphabetical -> list.sortedBy { it.name }
                    .toPersistentList()

                ChapterSortingMethodType.RevAlphabetical -> list.sortedByDescending { it.name }
                    .toPersistentList()
            }

            return sorted
        }

        @CheckResult
        fun new(
            items: PersistentList<ImmutableChapterData>,
            query: String,
            sortingMethod: ChapterSortingMethodType
        ): ImmutableChapterList {
            val filtered = filterList(items, query)
            val sorted = sortList(filtered, sortingMethod)
            return ImmutableChapterList(
                data = items,
                filtered = filtered,
                sorted = sorted,
                query = query,
                sortingMethod = sortingMethod
            )
        }
    }
}

/**
 * Viewmodel -> UI
 *
 * The base container for locally searchable items.
 *
 * This includes options for both filtering with a query, and sorting it by a SortingMethodType
 * */
@Immutable
data class ImmutableSearchList(
    private val internalData: SearchableData<Int, ImmutableSearchResponse> = SearchableData(
        data = persistentMapOf(),
        filtered = persistentSetOf(),
        sorted = persistentListOf(),
        filteredBy = null,
        sortedBy = SortByName { it.name }
    ),
    val query: String = "",
    val sortingMethod: SortingMethodType = SortingMethodType.Default,
) {
    val data = internalData.data
    //val filtered = internalData.filtered
    val sorted = internalData.sorted

    @CheckResult
    fun delete(id: Int): ImmutableSearchList {
        return copy(internalData = internalData.removing(id))
    }

    @CheckResult
    fun insert(
        id: Int,
        newItem: ImmutableSearchResponse
    ): ImmutableSearchList {
        return copy(internalData = internalData.adding(id, newItem))
    }

    @CheckResult
    fun update(
        id: Int,
        updater: ImmutableSearchResponse.() -> ImmutableSearchResponse
    ): ImmutableSearchList {
        return copy(internalData = internalData.updating(id, updater))
    }

    @CheckResult
    fun search(
        query: String = this.query,
        sortingMethod: SortingMethodType = this.sortingMethod
    ): ImmutableSearchList {
        val sameQuery = this.query == query
        val sameSorting = this.sortingMethod == sortingMethod
        if (sameQuery && sameSorting) {
            return this
        }

        return copy(
            internalData = internalData.searchBy(
                newSorting = getSortingMethod(sortingMethod),
                newFilter = getQuery(query),
            ),
            sortingMethod = sortingMethod,
            query = query
        )
    }

    companion object {
        private val Alphabetical = SortByName<ImmutableSearchResponse> { it.name }
        private val RevAlphabetical = SortByName<ImmutableSearchResponse> { it.name }.rev()
        private val DownloadCount =
            sortByLong<ImmutableSearchResponse> { it.downloadState?.downloaded ?: 0L }.rev()
        private val RevDownloadCount =
            sortByLong<ImmutableSearchResponse> { it.downloadState?.downloaded ?: 0L }
        private val DownloadPercentage = sortByFloat<ImmutableSearchResponse> {
            it.downloadState?.downloadPercentage ?: 0.0f
        }.rev()
        private val RevDownloadPercentage =
            sortByFloat<ImmutableSearchResponse> { it.downloadState?.downloadPercentage ?: 0.0f }
        private val LastOpened =
            sortByLong<ImmutableSearchResponse> { it.timeOfPageOpened ?: 0L }.rev()
        private val RevLastOpened =
            sortByLong<ImmutableSearchResponse> { it.timeOfPageOpened ?: 0L }
        private val LastNewChapterDownloaded =
            sortByLong<ImmutableSearchResponse> { it.timeOfChapterDownloaded ?: 0L }.rev()
        private val RevLastNewChapterDownloaded =
            sortByLong<ImmutableSearchResponse> { it.timeOfChapterDownloaded ?: 0L }
        private val LastCached = sortByLong<ImmutableSearchResponse> { it.timeOfCached }.rev()
        private val RevLastCached = sortByLong<ImmutableSearchResponse> { it.timeOfCached }
        private val ChapterCount = sortByLong<ImmutableSearchResponse> { it.chapters ?: 0L }.rev()
        private val RevChapterCount = sortByLong<ImmutableSearchResponse> { it.chapters ?: 0L }
        private val DefaultQuery = FilterByQuery<ImmutableSearchResponse>("") { it.name }

        private fun getQuery(query: String): FilterByQuery<ImmutableSearchResponse>? {
            return if (query.length < 2) {
                null
            } else {
                DefaultQuery.update(query)
            }
        }

        private fun getSortingMethod(method: SortingMethodType): Comparator<ImmutableSearchResponse> {
            return when (method) {
                SortingMethodType.Alphabetical -> Alphabetical

                SortingMethodType.RevAlphabetical -> RevAlphabetical

                SortingMethodType.DownloadCount -> DownloadCount

                SortingMethodType.RevDownloadCount -> RevDownloadCount

                SortingMethodType.DownloadPercentage -> DownloadPercentage

                SortingMethodType.RevDownloadPercentage -> RevDownloadPercentage

                SortingMethodType.Default, SortingMethodType.LastOpened -> LastOpened

                SortingMethodType.RevLastOpened -> RevLastOpened

                SortingMethodType.LastNewChapterDownloaded -> LastNewChapterDownloaded

                SortingMethodType.RevLastNewChapterDownloaded -> RevLastNewChapterDownloaded

                SortingMethodType.LastCached -> LastCached

                SortingMethodType.RevLastCached -> RevLastCached

                SortingMethodType.ChapterCount -> ChapterCount

                SortingMethodType.RevChapterCount -> RevChapterCount
            }
        }

        @CheckResult
        fun new(
            items: PersistentMap<Int, ImmutableSearchResponse>,
            query: String,
            sortingMethod: SortingMethodType
        ): ImmutableSearchList {
            return ImmutableSearchList(
                query = query,
                sortingMethod = sortingMethod,
                internalData = SearchableData.from(
                    data = items,
                    sortedBy = getSortingMethod(sortingMethod),
                    filteredBy = getQuery(query)
                )
            )
        }
    }
}
