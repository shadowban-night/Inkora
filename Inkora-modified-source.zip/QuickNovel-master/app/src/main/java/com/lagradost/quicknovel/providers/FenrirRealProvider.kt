package com.lagradost.quicknovel.providers

import com.lagradost.quicknovel.HeadMainPageResponse
import com.lagradost.quicknovel.LoadResponse
import com.lagradost.quicknovel.MainAPI
import com.lagradost.quicknovel.R
import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.fixUrlNull
import com.lagradost.quicknovel.newSearchResponse
import com.lagradost.quicknovel.newStreamResponse
import com.lagradost.quicknovel.setStatus
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.quicknovel.ErrorLoadingException
import com.lagradost.quicknovel.UserReview
import com.lagradost.quicknovel.newChapterData
import com.lagradost.quicknovel.newReview
import org.jsoup.Jsoup
import kotlin.collections.map

class FenrirRealProvider : MainAPI() {
    override val name = "FenrirRealm"
    override val mainUrl = "https://fenrirealm.com"
    override val iconId = R.drawable.icon_fenrirealm
    override val hasMainPage = true

    //I don't know why, but this fixes the timeout issue for this provider
    override val rateLimitTime = 3000L
    override val hasReviews = true
    override val usesCloudFlareKiller = true

    override val mainCategories = listOf(
        "All" to "any",
        "Completed" to "completed",
        "Ongoing" to "on-going"
    )
    override val orderBys =
        listOf(
            "Popular" to "popular",
            "Latest" to "latest",
            "Updated" to "updated"
        )
    override val tags = listOf(
        "All" to "0",
        "Action" to "1",
        "Adult" to "2",
        "Adventure" to "3",
        "Comedy" to "4",
        "Drama" to "5",
        "Ecchi" to "6",
        "Fantasy" to "7",
        "Gender Bender" to "8",
        "Harem" to "9",
        "Historical" to "10",
        "Horror" to "11",
        "Josei" to "12",
        "Martial Arts" to "13",
        "Mature" to "14",
        "Mecha" to "15",
        "Mystery" to "16",
        "Psychological" to "17",
        "Romance" to "18",
        "School Life" to "19",
        "Sci-fi" to "20",
        "Seinen" to "21",
        "Shoujo" to "22",
        "Shoujo Ai" to "23",
        "Shounen" to "24",
        "Shounen Ai" to "25",
        "Slice of Life" to "26",
        "Smut" to "27",
        "Sports" to "28",
        "Supernatural" to "29",
        "Tragedy" to "30",
        "Wuxia" to "31",
        "Xianxia" to "32",
        "Xuanhuan" to "33",
        "Yaoi" to "34",
        "Yuri" to "35",
    )

    fun String.getSlugFromUrl() = this.substringAfterLast("/series/")

    override suspend fun loadMainPage(
        page: Int,
        mainCategory: String?,
        orderBy: String?,
        tag: String?
    ): HeadMainPageResponse {
        val url =
            if (tag != "0") "$mainUrl/api/new/v2/series?page=$page&per_page=12&status=$mainCategory&sort=$orderBy&tags%5B%5D=$tag"
            else "$mainUrl/api/new/v2/series?page=$page&per_page=24&status=$mainCategory&sort=$orderBy"
        val document = app.get(url).parsed<FenrirMainPageResponse>()
        val returnValue = document.data.map { novel ->
            newSearchResponse(
                name = novel.title,
                url = mainUrl + "/series/" + novel.slug
            ) {
                posterUrl = fixUrlNull(novel.cover)
            }

        }
        return HeadMainPageResponse(url, returnValue)
    }

    suspend fun getRelated(url: String): List<SearchResponse> {
        val name = url.substringAfter("/series/").removeSuffix("/")
        val url = "$mainUrl/api/new/v2/series/$name/recommendations?limit=10"
        val document = app.get(url).parsed<FenrirMainPageResponse>()
        return document.data.map { element ->
            val href = "$mainUrl/series/${element.slug}"
            val title = element.title
            newSearchResponse(
                name = title,
                url = href
            ) {
                posterUrl = fixUrlNull(
                    element.cover
                )
            }
        }
    }

    override suspend fun load(url: String): LoadResponse {
        val document = app.get(url).document
        document.select("style, iframe, svg, noscript").remove()//avoid out of memory
        val infoDiv = document.select("div#series-info")
        val chapters = app
            .get("$mainUrl/api/new/v2/series/${url.getSlugFromUrl()}/chapters")
            .parsed<Array<ChapterInf>>()
            .mapNotNull { ch ->
                if (ch.locked.price > 0) null
                else newChapterData(
                    "${ch.name} ${if (ch.title.isNullOrEmpty()) "" else "- ${ch.title}"}",
                    "$mainUrl/api/new/v2/series/${url.getSlugFromUrl()}/${ch.slug}"
                ) {
                    dateOfRelease = ch.updatedAt.split("T")[0]
                }
            }

        val title = infoDiv.selectFirst("h1")?.text() ?: throw Exception("Title not found")
        val script =
            document.select("script").find { it.html().contains("seriesData") }?.html() ?: ""

        return newStreamResponse(title, url, chapters) {
            infoDiv.select(" > div").forEachIndexed { index, inf ->
                when (index) {
                    1 -> {
                        setStatus(inf.selectFirst("span")?.text())
                    }

                    2 -> {
                        this.author = inf.selectFirst("a")?.text()
                    }

                    3 -> {
                        this.tags = infoDiv.select("a").mapNotNull {
                            it.text().trim().takeIf { text -> text.isNotEmpty() }
                        }
                    }
                }
            }
            this.synopsis = document.selectFirst("div.synopsis")?.text()
            this.posterUrl = document.selectFirst("meta[property=og:image]")?.attr("content")
            related = getRelated(url)
            reviewData = Regex("""seriesData:\{id:(\d+)""").find(script)?.groupValues?.get(1)
        }
    }


    override suspend fun loadReviews(url: String, page: Int, data: String?): List<UserReview> {
        val libraryId = data ?: return emptyList()

        val realUrl = "$mainUrl/api/new/v2/comments/series/$libraryId?page=$page&sort=latest"
        val res = app.get(realUrl).parsed<CommentsResponse>()
        return res.data.map { comment ->
            newReview(comment.content) {
                username = comment.user.username
                date = comment.createdAt.split("T").firstOrNull()
                avatarUrl = comment.user.avatar
            }
        }
    }

    override suspend fun loadHtml(url: String): String? {
        val response = app.get(url).parsed<ChapterResponse>()

        val chapterHtml = Jsoup.parse(response.content ?: return null)
        chapterHtml.select("script, style, iframe, svg, noscript").remove()
        chapterHtml.select("[aria-hidden=\"true\"]").remove()
        return chapterHtml.html()
    }


    override suspend fun search(query: String): List<SearchResponse> {
        val url = "$mainUrl/api/new/v2/series?page=1&per_page=5&search=$query"
        val document = app.get(url).parsed<FenrirMainPageResponse>()

        return document.data.map { novel ->
            val title = novel.title
            val novelUrl = mainUrl + "/series/" + novel.slug
            newSearchResponse(title, novelUrl) {
                posterUrl = fixUrlNull(novel.cover)
            }
        }
    }


    data class FenrirMainPageResponse(
        @JsonProperty("data")
        val data: List<Daum>,
    )

    data class Daum(
        // Novel inf
        @JsonProperty("title")
        val title: String,
        @JsonProperty("slug")
        val slug: String,
        @JsonProperty("cover")
        val cover: String,
    )

    data class ChapterInf(
        @JsonProperty("slug")
        val slug: String,
        @JsonProperty("name")
        val name: String,
        @JsonProperty("title")
        val title: String?,
        @JsonProperty("updated_at")
        val updatedAt: String,
        @JsonProperty("locked")
        val locked: Locked,
    )

    data class Locked(
        @JsonProperty("price")
        val price: Int,
    )

    data class CommentsResponse(
        @JsonProperty("data")
        val data: List<CommentData>
    )

    data class CommentData(
        @JsonProperty("content")
        val content: String,
        @JsonProperty("created_at")
        val createdAt: String,
        @JsonProperty("user")
        val user: CommentUser
    )

    data class CommentUser(
        @JsonProperty("username")
        val username: String,
        @JsonProperty("avatar")
        val avatar: String?
    )

    data class ChapterResponse(
        @JsonProperty("content")
        val content: String?
    )
}